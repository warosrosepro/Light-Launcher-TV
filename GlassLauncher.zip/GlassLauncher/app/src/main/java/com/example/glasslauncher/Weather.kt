package com.example.glasslauncher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Net {
    fun getBytes(url: String, limit: Int = 20_000_000): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.instanceFollowRedirects = true
        try {
            if (c.contentLength > limit) throw IllegalStateException("too big")
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }
}

object Weather {
    class Geo(val name: String, val lat: Double, val lon: Double)
    class Result(val temp: Int, val code: Int)

    fun geocode(city: String): Geo? {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(city, "UTF-8") + "&count=1&language=ru&format=json"
        val json = JSONObject(String(Net.getBytes(url), Charsets.UTF_8))
        val arr = json.optJSONArray("results") ?: return null
        if (arr.length() == 0) return null
        val o = arr.getJSONObject(0)
        return Geo(o.optString("name", city), o.getDouble("latitude"), o.getDouble("longitude"))
    }

    fun fetch(lat: Double, lon: Double): Result? {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,weather_code&timezone=auto"
        val json = JSONObject(String(Net.getBytes(url), Charsets.UTF_8))
        val cur = json.optJSONObject("current") ?: return null
        return Result(Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"))
    }

    fun describe(code: Int): String = when (code) {
        0 -> "Ясно"
        1 -> "Малооблачно"
        2 -> "Переменная облачность"
        3 -> "Пасмурно"
        45, 48 -> "Туман"
        51, 53, 55 -> "Морось"
        56, 57 -> "Ледяная морось"
        61, 63, 65 -> "Дождь"
        66, 67 -> "Ледяной дождь"
        71, 73, 75, 77 -> "Снег"
        80, 81, 82 -> "Ливень"
        85, 86 -> "Снегопад"
        95, 96, 99 -> "Гроза"
        else -> "—"
    }
}
