package com.example.glasslauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint

object Backgrounds {

    /** Обрезает картинку по центру под нужный размер. */
    fun centerCrop(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
        val dx = (w - src.width * scale) / 2f
        val dy = (h - src.height * scale) / 2f
        val m = Matrix()
        m.setScale(scale, scale)
        m.postTranslate(dx, dy)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /**
     * Размытая копия фона. Делается ОДИН раз на маленькой картинке,
     * поэтому «стекло» на плитках почти ничего не стоит по скорости.
     */
    fun blur(src: Bitmap): Bitmap {
        val w = 192
        val h = 108
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val a = IntArray(w * h)
        small.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h)
        repeat(3) {
            box(a, b, w, h, 4, true)
            box(b, a, w, h, 4, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }

    private fun box(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val step = if (horizontal) 1 else w
        val div = 2 * r + 1
        for (l in 0 until lines) {
            val start = if (horizontal) l * w else l
            var sa = 0
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val p = src[start + i.coerceIn(0, len - 1) * step]
                sa += p ushr 24
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (i in 0 until len) {
                dst[start + i * step] =
                    ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[start + minOf(i + r + 1, len - 1) * step]
                val rem = src[start + maxOf(i - r, 0) * step]
                sa += (add ushr 24) - (rem ushr 24)
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }
}
