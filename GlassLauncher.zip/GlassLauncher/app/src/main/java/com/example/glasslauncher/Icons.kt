package com.example.glasslauncher

import android.graphics.Path

/**
 * Иконки кнопок. Рисуются из контуров (сетка 24x24), поэтому чёткие на любом размере.
 * Формат контура: M x y, L x y ..., Q x1 y1 x y, C ..., Z (все числа через пробел).
 */
object Icons {
    class Def(val stroke: String, val fill: String, val accent: Int)

    val defs = HashMap<Int, Def>()

    init {
        defs[1] = Def(
            "M 19.13 10.42 L 21.9 10.61 21.9 13.39 19.13 13.58 18.74 14.79 18.16 15.92 19.99 18.02 18.02 19.99 15.92 18.16 14.79 18.74 13.58 19.13 13.39 21.9 10.61 21.9 10.42 19.13 9.21 18.74 8.08 18.16 5.98 19.99 4.01 18.02 5.84 15.92 5.26 14.79 4.87 13.58 2.1 13.39 2.1 10.61 4.87 10.42 5.26 9.21 5.84 8.08 4.01 5.98 5.98 4.01 8.08 5.84 9.21 5.26 10.42 4.87 10.61 2.1 13.39 2.1 13.58 4.87 14.79 5.26 15.92 5.84 18.02 4.01 19.99 5.98 18.16 8.08 18.74 9.21 Z M 15.1 12 L 14.91 13.06 14.37 13.99 13.55 14.68 12.54 15.05 11.46 15.05 10.45 14.68 9.63 13.99 9.09 13.06 8.9 12 9.09 10.94 9.63 10.01 10.45 9.32 11.46 8.95 12.54 8.95 13.55 9.32 14.37 10.01 14.91 10.94 Z",
            "",
            0xFF5AA9FFL.toInt()
        )
        defs[2] = Def(
            "",
            "M 10.5 5 Q 11.78 12.22 19 13.5 Q 11.78 14.78 10.5 22 Q 9.22 14.78 2 13.5 Q 9.22 12.22 10.5 5 Z M 19 1.9 Q 19.54 4.96 22.6 5.5 Q 19.54 6.04 19 9.1 Q 18.46 6.04 15.4 5.5 Q 18.46 4.96 19 1.9 Z",
            0xFF34D399L.toInt()
        )
        defs[3] = Def(
            "M 5 5 L 19 5 Q 21 5 21 7 L 21 15 Q 21 17 19 17 L 5 17 Q 3 17 3 15 L 3 7 Q 3 5 5 5 Z M 8 21 L 16 21 M 12 17 L 12 21 M 8 11 L 15 11 M 12.5 8.5 L 15 11 L 12.5 13.5",
            "",
            0xFFFBBF24L.toInt()
        )
        defs[4] = Def(
            "M 11 4 L 6 4 Q 4 4 4 6 L 4 18 Q 4 20 6 20 L 11 20 M 10 12 L 20 12 M 16 8 L 20 12 L 16 16",
            "",
            0xFFFF7A7AL.toInt()
        )
    }

    fun parse(d: String): Path {
        val p = Path()
        if (d.isEmpty()) return p
        val t = d.trim().split(" ").filter { it.isNotEmpty() }
        var i = 0
        fun isNum(s: String): Boolean = s[0].isDigit() || s[0] == '-' || s[0] == '.'
        fun nx(): Float = t[i++].toFloat()
        while (i < t.size) {
            val cmd = t[i++]
            when (cmd) {
                "M" -> {
                    val x = nx()
                    val y = nx()
                    p.moveTo(x, y)
                }
                "L" -> {
                    while (i < t.size && isNum(t[i])) {
                        val x = nx()
                        val y = nx()
                        p.lineTo(x, y)
                    }
                }
                "Q" -> {
                    while (i < t.size && isNum(t[i])) {
                        val x1 = nx()
                        val y1 = nx()
                        val x = nx()
                        val y = nx()
                        p.quadTo(x1, y1, x, y)
                    }
                }
                "C" -> {
                    while (i < t.size && isNum(t[i])) {
                        val x1 = nx()
                        val y1 = nx()
                        val x2 = nx()
                        val y2 = nx()
                        val x = nx()
                        val y = nx()
                        p.cubicTo(x1, y1, x2, y2, x, y)
                    }
                }
                "Z" -> p.close()
            }
        }
        return p
    }
}
