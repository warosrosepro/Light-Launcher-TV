package com.example.glasslauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.text.TextPaint
import android.text.TextUtils
import android.view.View
import android.widget.ScrollView

/** Фон на весь экран + лёгкое затемнение сверху, чтобы читались часы и погода. */
class BgView(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
        set(v) {
            field = v
            invalidate()
        }
    private val p = Paint(Paint.FILTER_BITMAP_FLAG)
    private val scrim = Paint()
    private val dst = Rect()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        scrim.shader = LinearGradient(
            0f, 0f, 0f, h * 0.45f,
            0x99000000.toInt(), 0x00000000, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val b = bmp ?: return
        dst.set(0, 0, width, height)
        canvas.drawBitmap(b, null, dst, p)
        canvas.drawRect(0f, 0f, width.toFloat(), height * 0.45f, scrim)
    }
}

/** ScrollView, который сообщает о прокрутке, чтобы «стекло» плиток обновлялось. */
class GlassScroll(ctx: Context) : ScrollView(ctx) {
    var onScrolled: (() -> Unit)? = null

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrolled?.invoke()
    }
}

/**
 * Плитка приложения: стеклянный «суперэллипс» (как иконки на Mac) с иконкой внутри
 * и подписью под ним. Для кнопки (isButton) рисуется стеклянная «таблетка».
 */
class GlassTile(ctx: Context, val key: String, val label: String) : View(ctx) {
    var icon: Bitmap? = null
    var isButton = false
    /** 0 — текст, иначе номер иконки из Icons: 1 настройки, 2 очистка, 3 вход, 4 выход */
    var glyph = 0
    var blur: Bitmap? = null
    var screenW = 1
    var screenH = 1
    var moving = false
        set(v) {
            field = v
            applyScale()
            invalidate()
        }

    private val d = ctx.resources.displayMetrics.density
    private val loc = IntArray(2)
    private val rect = RectF()
    private val dst = RectF()
    private val iconDst = RectF()
    private val clip = Path()
    private val border = Path()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val tint = Paint()
    private val hi = Paint()
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        setShadowLayer(3f * d, 0f, 1f * d, 0x99000000.toInt())
    }
    private var shown: CharSequence = label
    private var sq = 0f
    private val gp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val gf = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val accentPaint = Paint()
    private var gStroke: Path? = null
    private var gFill: Path? = null
    private var accent = 0

    init {
        isFocusable = true
        isClickable = true
    }

    private fun applyScale() {
        val s = if (moving) 1.15f else if (isFocused) (if (isButton) (if (glyph != 0) 1.15f else 1.05f) else 1.12f) else 1f
        animate().scaleX(s).scaleY(s).setDuration(140).start()
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        applyScale()
        invalidate()
    }

    /** Суперэллипс (форма иконок Apple): |x|^5 + |y|^5 = 1 */
    private fun squircle(p: Path, l: Float, t: Float, r: Float, b: Float) {
        p.reset()
        val cx = (l + r) / 2f
        val cy = (t + b) / 2f
        val rx = (r - l) / 2f
        val ry = (b - t) / 2f
        val steps = 96
        for (i in 0..steps) {
            val a = 2.0 * Math.PI * i / steps
            val c = Math.cos(a)
            val s = Math.sin(a)
            val x = cx + rx * Math.signum(c) * Math.pow(Math.abs(c), 0.4)
            val y = cy + ry * Math.signum(s) * Math.pow(Math.abs(s), 0.4)
            if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
        }
        p.close()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val inset = 2f * d
        if (isButton) {
            sq = h.toFloat()
            clip.reset()
            clip.addRoundRect(0f, 0f, w.toFloat(), h.toFloat(), h / 2f, h / 2f, Path.Direction.CW)
            border.reset()
            val rr = (h - 2 * inset) / 2f
            border.addRoundRect(inset, inset, w - inset, h - inset, rr, rr, Path.Direction.CW)
            text.textSize = h * 0.38f
            shown = TextUtils.ellipsize(label, TextPaint(text), w * 0.9f, TextUtils.TruncateAt.END)
            val def = Icons.defs[glyph]
            if (def != null) {
                val gs = h * 0.58f
                val mx = Matrix()
                mx.setScale(gs / 24f, gs / 24f)
                mx.postTranslate((w - gs) / 2f, (h - gs) / 2f)
                val sp = Icons.parse(def.stroke)
                sp.transform(mx)
                gStroke = sp
                val fp = Icons.parse(def.fill)
                fp.transform(mx)
                gFill = fp
                gp.strokeWidth = gs / 24f * 1.9f
                gf.strokeWidth = gs / 24f * 0.9f
                accent = def.accent
            }
        } else {
            sq = w.toFloat()
            squircle(clip, 0f, 0f, sq, sq)
            squircle(border, inset, inset, sq - inset, sq - inset)
            text.textSize = sq * 0.15f
            shown = TextUtils.ellipsize(label, TextPaint(text), w * 1.08f, TextUtils.TruncateAt.END)
        }
        hi.shader = LinearGradient(0f, 0f, 0f, sq, 0x45FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        pivotX = w / 2f
        pivotY = sq / 2f
    }

    /** Иконка кнопки: контуры из Icons (линии и заливка). */
    private fun drawGlyph(c: Canvas) {
        val fp = gFill
        if (fp != null) c.drawPath(fp, gf)
        val sp = gStroke
        if (sp != null) c.drawPath(sp, gp)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()

        c.save()
        c.clipPath(clip)

        // «Стекло»: кусочек заранее размытого фона ровно под плиткой
        val b = blur
        if (b != null) {
            getLocationInWindow(loc)
            dst.set(
                -loc[0].toFloat(), -loc[1].toFloat(),
                -loc[0] + screenW.toFloat(), -loc[1] + screenH.toFloat()
            )
            c.drawBitmap(b, null, dst, bmpPaint)
        } else {
            c.drawColor(0x33000000)
        }

        val hot = isFocused || moving
        tint.color = if (hot) 0x55FFFFFF else 0x30FFFFFF
        c.drawRect(0f, 0f, w, sq, tint)
        if (isButton && glyph != 0) {
            accentPaint.color = (accent and 0x00FFFFFF) or ((if (hot) 0x99 else 0x66) shl 24)
            c.drawRect(0f, 0f, w, sq, accentPaint)
        }
        c.drawRect(0f, 0f, w, sq, hi)

        val ic = icon
        if (isButton) {
            if (glyph != 0) {
                drawGlyph(c)
            } else {
                c.drawText(shown, 0, shown.length, w / 2f, sq / 2f - (text.ascent() + text.descent()) / 2f, text)
            }
        } else if (ic != null) {
            val s = sq * 0.64f
            val o = (sq - s) / 2f
            iconDst.set(o, o, o + s, o + s)
            c.drawBitmap(ic, null, iconDst, bmpPaint)
        }
        c.restore()

        // Рамка
        val sw = (if (hot) 3f else 1.5f) * d
        stroke.strokeWidth = sw
        stroke.color = if (moving) 0xFF5AC8FA.toInt() else if (isFocused) 0xF2FFFFFF.toInt() else 0x66FFFFFF
        c.drawPath(border, stroke)

        // Подпись под плиткой
        if (!isButton) {
            c.drawText(shown, 0, shown.length, w / 2f, sq + text.textSize * 1.35f, text)
        }
    }
}

/** Простая иконка погоды, нарисованная кодом (без картинок и шрифтов). */
class WeatherIconView(ctx: Context) : View(ctx) {
    var code = -1
        set(v) {
            field = v
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bolt = Path()

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (code < 0 || s <= 0f) return

        if (code == 0) {
            sun(c, s * 0.5f, s * 0.5f, s * 0.22f)
            return
        }
        if (code in 1..2) sun(c, s * 0.36f, s * 0.34f, s * 0.17f)

        p.style = Paint.Style.FILL
        p.color = if (code == 3 || code >= 45) 0xFFD5DBE6.toInt() else 0xFFF4F7FF.toInt()
        c.drawCircle(s * 0.36f, s * 0.58f, s * 0.15f, p)
        c.drawCircle(s * 0.54f, s * 0.50f, s * 0.20f, p)
        c.drawCircle(s * 0.72f, s * 0.60f, s * 0.14f, p)
        c.drawRoundRect(s * 0.26f, s * 0.58f, s * 0.82f, s * 0.74f, s * 0.08f, s * 0.08f, p)

        val rain = code in 51..67 || code in 80..82
        val snow = code in 71..77 || code in 85..86
        val storm = code >= 95
        val fog = code == 45 || code == 48

        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = s * 0.045f
        if (rain || storm) {
            p.color = 0xFF6EC1FF.toInt()
            for (x in floatArrayOf(0.38f, 0.54f, 0.70f)) {
                c.drawLine(s * x, s * 0.80f, s * (x - 0.04f), s * 0.93f, p)
            }
        }
        if (snow) {
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            for (x in floatArrayOf(0.38f, 0.54f, 0.70f)) c.drawCircle(s * x, s * 0.87f, s * 0.035f, p)
        }
        if (fog) {
            p.color = 0xFFD5DBE6.toInt()
            c.drawLine(s * 0.24f, s * 0.84f, s * 0.80f, s * 0.84f, p)
            c.drawLine(s * 0.32f, s * 0.93f, s * 0.72f, s * 0.93f, p)
        }
        if (storm) {
            p.style = Paint.Style.FILL
            p.color = 0xFFFFD43B.toInt()
            bolt.reset()
            bolt.moveTo(s * 0.56f, s * 0.68f)
            bolt.lineTo(s * 0.44f, s * 0.86f)
            bolt.lineTo(s * 0.54f, s * 0.86f)
            bolt.lineTo(s * 0.48f, s * 1.0f)
            bolt.lineTo(s * 0.66f, s * 0.80f)
            bolt.lineTo(s * 0.55f, s * 0.80f)
            bolt.close()
            c.drawPath(bolt, p)
        }
    }

    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.color = 0xFFFFC83D.toInt()
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.28f
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val x1 = cx + Math.cos(a).toFloat() * r * 1.4f
            val y1 = cy + Math.sin(a).toFloat() * r * 1.4f
            val x2 = cx + Math.cos(a).toFloat() * r * 1.75f
            val y2 = cy + Math.sin(a).toFloat() * r * 1.75f
            c.drawLine(x1, y1, x2, y2, p)
        }
    }
}
