package com.example.glasslauncher

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class AppItem(
        val pkg: String,
        val cn: ComponentName,
        val label: String,
        val icon: Bitmap?,
        val banner: Boolean
    )

    private val bgNames = listOf(
        "Горы на закате", "Океан", "Ночной лес", "Северное сияние",
        "Пустыня", "Туманное утро", "Звёздная ночь", "Над облаками",
        "Синтвейв", "Туманность", "Лунное озеро", "Холодный рассвет",
        "Тропический закат", "Золотая осень", "Лавандовые холмы", "Ночные дюны"
    )
    private val bgRes = intArrayOf(
        R.drawable.bg_1, R.drawable.bg_2, R.drawable.bg_3, R.drawable.bg_4,
        R.drawable.bg_5, R.drawable.bg_6, R.drawable.bg_7, R.drawable.bg_8,
        R.drawable.bg_9, R.drawable.bg_10, R.drawable.bg_11, R.drawable.bg_12,
        R.drawable.bg_13, R.drawable.bg_14, R.drawable.bg_15, R.drawable.bg_16
    )

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var bgView: BgView
    private lateinit var scroll: GlassScroll
    private lateinit var content: LinearLayout
    private lateinit var tempText: TextView
    private lateinit var descText: TextView
    private lateinit var weatherIcon: WeatherIconView
    private lateinit var settingsBtn: GlassTile
    private val headerBtns = ArrayList<GlassTile>()
    private lateinit var hintText: TextView

    private val tiles = ArrayList<GlassTile>()
    private val allItems = ArrayList<AppItem>()
    private var pinned = LinkedHashSet<String>()
    private lateinit var column: LinearLayout
    private lateinit var appsBtn: GlassTile
    private lateinit var appsLayer: FrameLayout
    private lateinit var appsBg: BgView
    private lateinit var appsScroll: GlassScroll
    private lateinit var appsContent: LinearLayout
    private lateinit var appsTitle: TextView
    private val appsTiles = ArrayList<GlassTile>()
    private var appsOpen = false
    private var curBg: Bitmap? = null
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var blurBmp: Bitmap? = null
    private var cols = 7
    private var movingTile: GlassTile? = null
    private var screenW = 1
    private var screenH = 1
    private var lastWeather = 0L

    private val weatherTick = object : Runnable {
        override fun run() {
            loadWeather()
            ui.postDelayed(this, 1_800_000L)
        }
    }

    private val reloadApps = Runnable { loadApps() }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            ui.removeCallbacks(reloadApps)
            ui.postDelayed(reloadApps, 800)
        }
    }

    // ---------------------------------------------------------------- жизненный цикл

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("glass", MODE_PRIVATE)
        val dm = resources.displayMetrics
        screenW = dm.widthPixels
        screenH = dm.heightPixels
        cols = prefs.getInt("cols2", 7)
        buildUi()
        showCachedWeather()
        loadBackground()
        loadApps()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addDataScheme("package")
        registerReceiver(pkgReceiver, f)
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        val age = System.currentTimeMillis() - lastWeather
        ui.removeCallbacks(weatherTick)
        ui.postDelayed(weatherTick, if (age > 600_000L) 0L else 1_800_000L - age)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(weatherTick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Нажали «Домой»
        if (appsOpen) closeApps()
        if (movingTile != null) endMove()
        scroll.smoothScrollTo(0, 0)
        tiles.firstOrNull()?.requestFocus()
    }

    override fun onBackPressed() {
        if (appsOpen) {
            closeApps()
            return
        }
        if (movingTile != null) endMove()
        // На главном экране «Назад» ничего не делает
    }

    // ---------------------------------------------------------------- интерфейс

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val m = (screenW * 0.05f).toInt()

        val root = FrameLayout(this)
        bgView = BgView(this)
        root.addView(bgView, FrameLayout.LayoutParams(MATCH, MATCH))

        column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL

        // --- шапка: время и дата слева, погода и кнопка справа
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(m, dp(28), m, dp(12))

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL

        val clock = TextClock(this)
        clock.format24Hour = "HH:mm"
        clock.format12Hour = "HH:mm"
        clock.setTextColor(Color.WHITE)
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 52f)
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        clock.setShadowLayer(dp(4).toFloat(), 0f, dp(1).toFloat(), 0x99000000.toInt())

        val date = TextClock(this)
        date.format24Hour = "EEEE, d MMMM"
        date.format12Hour = "EEEE, d MMMM"
        date.setTextColor(0xE6FFFFFF.toInt())
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        date.setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), 0x99000000.toInt())

        left.addView(clock)
        left.addView(date)
        header.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))

        val weather = LinearLayout(this)
        weather.orientation = LinearLayout.HORIZONTAL
        weather.gravity = Gravity.CENTER_VERTICAL
        weatherIcon = WeatherIconView(this)
        weather.addView(weatherIcon, LinearLayout.LayoutParams(dp(56), dp(56)))

        val wt = LinearLayout(this)
        wt.orientation = LinearLayout.VERTICAL
        tempText = TextView(this)
        tempText.setTextColor(Color.WHITE)
        tempText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
        tempText.setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), 0x99000000.toInt())
        descText = TextView(this)
        descText.setTextColor(0xE6FFFFFF.toInt())
        descText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        descText.setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), 0x99000000.toInt())
        wt.addView(tempText)
        wt.addView(descText)
        val wtLp = LinearLayout.LayoutParams(WRAP, WRAP)
        wtLp.leftMargin = dp(12)
        weather.addView(wt, wtLp)
        applyWeatherSize()

        val wLp = LinearLayout.LayoutParams(WRAP, WRAP)
        wLp.rightMargin = dp(28)
        header.addView(weather, wLp)

        // --- три компактные круглые кнопки + подсказка под ними
        val btnBox = LinearLayout(this)
        btnBox.orientation = LinearLayout.VERTICAL
        btnBox.gravity = Gravity.CENTER_HORIZONTAL
        val btnRow = LinearLayout(this)
        btnRow.orientation = LinearLayout.HORIZONTAL

        hintText = TextView(this)
        hintText.setTextColor(Color.WHITE)
        hintText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        hintText.setSingleLine(true)
        hintText.text = " "
        hintText.setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), 0x99000000.toInt())

        settingsBtn = makeIconBtn("settings", "Настройки", 1) { showSettings() }
        val cleanBtn = makeIconBtn("clean", "Очистить память", 2) { cleanMemory() }
        val inputBtn = makeIconBtn("input", "Источник сигнала", 3) { showInputs() }
        val exitBtn = makeIconBtn("exit", "Выход в родной экран", 4) { exitToNative() }
        for (b in listOf(cleanBtn, inputBtn, settingsBtn, exitBtn)) {
            val lp = LinearLayout.LayoutParams(dp(46), dp(46))
            lp.leftMargin = dp(10)
            btnRow.addView(b, lp)
        }
        btnBox.addView(btnRow)
        val hLp = LinearLayout.LayoutParams(WRAP, WRAP)
        hLp.topMargin = dp(4)
        btnBox.addView(hintText, hLp)
        header.addView(btnBox, LinearLayout.LayoutParams(dp(224), WRAP))

        column.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- сетка плиток
        scroll = GlassScroll(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.clipToPadding = false
        scroll.onScrolled = { for (t in tiles) t.invalidate() }

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(m, dp(16), m, dp(110))
        scroll.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        column.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        // --- нижняя плашка «Приложения»
        appsBtn = GlassTile(this, "apps", "Приложения")
        appsBtn.isButton = true
        appsBtn.wide = true
        appsBtn.glyph = 5
        appsBtn.screenW = screenW
        appsBtn.screenH = screenH
        appsBtn.setOnClickListener { openApps() }
        headerBtns.add(appsBtn)
        val pillLp = FrameLayout.LayoutParams(dp(250), dp(52), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        pillLp.bottomMargin = dp(22)
        root.addView(appsBtn, pillLp)

        // --- экран «Все приложения»
        appsLayer = FrameLayout(this)
        appsLayer.visibility = View.GONE
        appsBg = BgView(this)
        appsLayer.addView(appsBg, FrameLayout.LayoutParams(MATCH, MATCH))
        val scrim = View(this)
        scrim.setBackgroundColor(0x99000000.toInt())
        appsLayer.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        val appsCol = LinearLayout(this)
        appsCol.orientation = LinearLayout.VERTICAL
        val ah = LinearLayout(this)
        ah.orientation = LinearLayout.VERTICAL
        ah.setPadding(m, dp(28), m, dp(12))
        appsTitle = TextView(this)
        appsTitle.text = "Все приложения"
        appsTitle.setTextColor(Color.WHITE)
        appsTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
        appsTitle.setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), 0x99000000.toInt())
        val appsHint = TextView(this)
        appsHint.text = "Назад — закрыть   ·   долгое ОК — закрепить на главном экране"
        appsHint.setTextColor(0xCCFFFFFF.toInt())
        appsHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        ah.addView(appsTitle)
        ah.addView(appsHint)
        appsCol.addView(ah, LinearLayout.LayoutParams(MATCH, WRAP))

        appsScroll = GlassScroll(this)
        appsScroll.isVerticalScrollBarEnabled = false
        appsScroll.overScrollMode = View.OVER_SCROLL_NEVER
        appsScroll.clipToPadding = false
        appsScroll.onScrolled = { for (t in appsTiles) t.invalidate() }
        appsContent = LinearLayout(this)
        appsContent.orientation = LinearLayout.VERTICAL
        appsContent.setPadding(m, dp(16), m, dp(48))
        appsScroll.addView(appsContent, FrameLayout.LayoutParams(MATCH, WRAP))
        appsCol.addView(appsScroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        appsLayer.addView(appsCol, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(appsLayer, FrameLayout.LayoutParams(MATCH, MATCH))

        setContentView(root)
    }

    /** Размер виджета погоды: 5 ступеней (0 — самый маленький). */
    private fun applyWeatherSize() {
        val lvl = prefs.getInt("wscale", 2).coerceIn(0, 4)
        val iconDp = intArrayOf(36, 46, 56, 68, 80)
        val tempSp = floatArrayOf(22f, 27f, 32f, 38f, 44f)
        val descSp = floatArrayOf(10f, 12f, 14f, 16f, 18f)
        weatherIcon.layoutParams = LinearLayout.LayoutParams(dp(iconDp[lvl]), dp(iconDp[lvl]))
        tempText.setTextSize(TypedValue.COMPLEX_UNIT_SP, tempSp[lvl])
        descText.setTextSize(TypedValue.COMPLEX_UNIT_SP, descSp[lvl])
    }

    private fun makeIconBtn(key: String, label: String, glyph: Int, action: () -> Unit): GlassTile {
        val b = GlassTile(this, key, label)
        b.isButton = true
        b.glyph = glyph
        b.screenW = screenW
        b.screenH = screenH
        b.setOnClickListener { action() }
        b.onFocusChangeListener = View.OnFocusChangeListener { _, has -> hintText.text = if (has) label else " " }
        headerBtns.add(b)
        return b
    }

    private fun toBitmap(d: Drawable, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, w, h)
        d.draw(Canvas(b))
        return b
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    // ---------------------------------------------------------------- приложения

    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val found = LinkedHashMap<String, ResolveInfo>()
            val tvPkgs = HashSet<String>()
            for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
                val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
                for (ri in pm.queryIntentActivities(q, 0)) {
                    val pkg = ri.activityInfo.packageName
                    if (cat == Intent.CATEGORY_LEANBACK_LAUNCHER) tvPkgs.add(pkg)
                    if (pkg != packageName && !found.containsKey(pkg)) found[pkg] = ri
                }
            }
            val list = ArrayList<AppItem>()
            for ((pkg, ri) in found) {
                try {
                    val ai = ri.activityInfo
                    val cn = ComponentName(ai.packageName, ai.name)
                    val label = ri.loadLabel(pm).toString()
                    list.add(AppItem(pkg, cn, label, toBitmap(ri.loadIcon(pm), 160, 160), pkg in tvPkgs))
                } catch (e: Exception) {
                }
            }
            ui.post { onAppsLoaded(list) }
        }
    }

    private fun onAppsLoaded(list: List<AppItem>) {
        allItems.clear()
        allItems.addAll(list)
        loadPinned()
        buildTiles(allItems.filter { it.pkg in pinned })
        buildAppsTiles()
    }

    /** Что показывать на главном экране. Первый запуск: до 14 приложений (сначала «телевизионные»). */
    private fun loadPinned() {
        val saved = prefs.getString("pinned", null)
        pinned = LinkedHashSet()
        if (saved == null) {
            val pick = allItems.sortedWith(compareByDescending<AppItem> { it.banner }.thenBy { it.label.lowercase() }).take(14)
            for (a in pick) pinned.add(a.pkg)
            savePinned()
        } else {
            for (p in saved.split("\n")) if (p.isNotEmpty()) pinned.add(p)
        }
    }

    private fun savePinned() {
        prefs.edit().putString("pinned", pinned.joinToString("\n")).apply()
    }

    private fun buildAppsTiles() {
        appsTiles.clear()
        for (a in allItems.sortedBy { it.label.lowercase() }) {
            val t = GlassTile(this, a.pkg, a.label)
            t.icon = a.icon
            t.blur = blurBmp
            t.screenW = screenW
            t.screenH = screenH
            t.tag = a.cn
            t.badge = a.pkg in pinned
            t.setOnClickListener { launch(a.cn) }
            t.setOnLongClickListener {
                appMenu(a)
                true
            }
            appsTiles.add(t)
        }
        appsTitle.text = "Все приложения (" + appsTiles.size + ")"
        layoutInto(appsContent, appsTiles)
    }

    private fun appMenu(a: AppItem) {
        val isPinned = a.pkg in pinned
        val items = arrayOf(if (isPinned) "Убрать с главного экрана" else "Закрепить на главном экране", "Открыть")
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setItems(items) { _, which ->
                if (which == 0) {
                    if (isPinned) pinned.remove(a.pkg) else pinned.add(a.pkg)
                    savePinned()
                    for (t in appsTiles) {
                        if (t.key == a.pkg) {
                            t.badge = !isPinned
                            t.invalidate()
                        }
                    }
                    buildTiles(allItems.filter { it.pkg in pinned })
                } else {
                    launch(a.cn)
                }
            }
            .show()
    }

    private fun openApps() {
        if (appsOpen) return
        if (movingTile != null) endMove()
        appsOpen = true
        appsBg.bmp = curBg
        column.visibility = View.GONE
        appsBtn.visibility = View.GONE
        appsLayer.alpha = 0f
        appsLayer.visibility = View.VISIBLE
        appsLayer.animate().alpha(1f).setDuration(180).start()
        appsScroll.scrollTo(0, 0)
        appsTiles.firstOrNull()?.requestFocus()
    }

    private fun closeApps() {
        if (!appsOpen) return
        appsOpen = false
        appsLayer.visibility = View.GONE
        column.visibility = View.VISIBLE
        appsBtn.visibility = View.VISIBLE
        appsBtn.requestFocus()
    }

    private fun buildTiles(items: List<AppItem>) {
        val focusedKey = (currentFocus as? GlassTile)?.key
        movingTile = null
        tiles.clear()

        val saved = (prefs.getString("order", "") ?: "").split("\n").filter { it.isNotEmpty() }
        val byPkg = HashMap<String, AppItem>()
        for (a in items) byPkg[a.pkg] = a

        val ordered = ArrayList<AppItem>()
        for (p in saved) {
            val a = byPkg[p]
            if (a != null) ordered.add(a)
        }
        val rest = items.filter { it.pkg !in saved }.sortedBy { it.label.lowercase() }
        ordered.addAll(rest)

        for (app in ordered) {
            val t = GlassTile(this, app.pkg, app.label)
            t.icon = app.icon
            t.blur = blurBmp
            t.screenW = screenW
            t.screenH = screenH
            t.tag = app.cn
            t.setOnClickListener {
                if (movingTile != null) endMove() else launch(app.cn)
            }
            t.setOnLongClickListener {
                startMove(t)
                true
            }
            tiles.add(t)
        }
        relayout()
        val target = tiles.firstOrNull { it.key == focusedKey } ?: tiles.firstOrNull()
        target?.requestFocus()
    }

    private fun relayout() {
        layoutInto(content, tiles)
        layoutInto(appsContent, appsTiles)
    }

    private fun layoutInto(host: LinearLayout, list: List<GlassTile>) {
        for (t in list) (t.parent as? ViewGroup)?.removeView(t)
        host.removeAllViews()

        val m = (screenW * 0.05f).toInt()
        val gap = dp(18)
        val inner = screenW - 2 * m
        val tw = (inner - (cols - 1) * gap) / cols
        val th = (tw * 1.32f).toInt()

        var row: LinearLayout? = null
        for (i in list.indices) {
            if (i % cols == 0) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                val rlp = LinearLayout.LayoutParams(MATCH, WRAP)
                rlp.bottomMargin = dp(8)
                host.addView(r, rlp)
                row = r
            }
            val lp = LinearLayout.LayoutParams(tw, th)
            if (i % cols != cols - 1) lp.rightMargin = gap
            row?.addView(list[i], lp)
        }
    }

    private fun launch(cn: ComponentName) {
        try {
            val i = Intent(Intent.ACTION_MAIN)
            i.component = cn
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            startActivity(i)
        } catch (e: Exception) {
            toast("Не удалось открыть приложение")
        }
    }

    // ---------------------------------------------------------------- перемещение плиток

    private fun startMove(t: GlassTile) {
        movingTile = t
        t.moving = true
        toast("Стрелками переместите плитку, ОК — готово")
    }

    private fun endMove() {
        movingTile?.moving = false
        movingTile = null
        saveOrder()
    }

    private fun moveBy(keyCode: Int) {
        val t = movingTile ?: return
        val i = tiles.indexOf(t)
        val j = when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> i - 1
            KeyEvent.KEYCODE_DPAD_RIGHT -> i + 1
            KeyEvent.KEYCODE_DPAD_UP -> i - cols
            KeyEvent.KEYCODE_DPAD_DOWN -> i + cols
            else -> i
        }
        if (i < 0 || j == i || j < 0 || j >= tiles.size) return
        tiles.removeAt(i)
        tiles.add(j, t)
        relayout()
        t.requestFocus()
        saveOrder()
    }

    private fun saveOrder() {
        prefs.edit().putString("order", tiles.joinToString("\n") { it.key }).apply()
    }

    override fun dispatchKeyEvent(event: KeyEvent?): Boolean {
        val e = event ?: return false
        if (movingTile != null) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT,
                    KeyEvent.KEYCODE_DPAD_RIGHT,
                    KeyEvent.KEYCODE_DPAD_UP,
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        moveBy(e.keyCode)
                        return true
                    }
                    KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                        endMove()
                        return true
                    }
                }
            } else if (e.action == KeyEvent.ACTION_UP && e.keyCode == KeyEvent.KEYCODE_BACK) {
                return true
            }
        }
        if (!appsOpen && movingTile == null && e.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            if (e.keyCode == KeyEvent.KEYCODE_DPAD_DOWN && f is GlassTile && tiles.contains(f)) {
                val lastRowStart = ((tiles.size - 1) / cols) * cols
                if (tiles.indexOf(f) >= lastRowStart) {
                    appsBtn.requestFocus()
                    return true
                }
            } else if (e.keyCode == KeyEvent.KEYCODE_DPAD_UP && f === appsBtn && tiles.isNotEmpty()) {
                val lastRowStart = ((tiles.size - 1) / cols) * cols
                tiles[minOf(tiles.size - 1, lastRowStart + cols / 2)].requestFocus()
                return true
            }
        }
        if (e.keyCode == KeyEvent.KEYCODE_MENU) {
            if (e.action == KeyEvent.ACTION_UP) showSettings()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    // ---------------------------------------------------------------- фон

    private fun loadBackground() {
        val key = prefs.getString("bg", "p0") ?: "p0"
        io.execute {
            var bmp: Bitmap? = null
            if (key == "custom") {
                val f = File(filesDir, "bg.jpg")
                if (f.exists()) bmp = BitmapFactory.decodeFile(f.path)
            }
            val result: Bitmap = bmp ?: run {
                val idx = (key.removePrefix("p").toIntOrNull() ?: 0).coerceIn(0, bgRes.size - 1)
                BitmapFactory.decodeResource(resources, bgRes[idx])
            }
            val blurred = Backgrounds.blur(result)
            ui.post { applyBackground(result, blurred) }
        }
    }

    private fun applyBackground(bmp: Bitmap, blurred: Bitmap) {
        bgView.bmp = bmp
        curBg = bmp
        appsBg.bmp = bmp
        blurBmp = blurred
        for (t in tiles) {
            t.blur = blurred
            t.invalidate()
        }
        for (t in appsTiles) {
            t.blur = blurred
            t.invalidate()
        }
        for (b in headerBtns) {
            b.blur = blurred
            b.invalidate()
        }
    }

    private fun setCustomBackground(bytes: ByteArray) {
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var s = 1
            while (o.outWidth / (s * 2) >= 1280 && o.outHeight / (s * 2) >= 720) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
                ?: throw IllegalStateException("decode failed")
            val bmp = Backgrounds.centerCrop(raw, 1280, 720)
            FileOutputStream(File(filesDir, "bg.jpg")).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            prefs.edit().putString("bg", "custom").apply()
            val blurred = Backgrounds.blur(bmp)
            ui.post { applyBackground(bmp, blurred) }
        } catch (e: Exception) {
            ui.post { toast("Не удалось загрузить картинку") }
        }
    }

    // ---------------------------------------------------------------- погода

    private fun showCachedWeather() {
        if (prefs.contains("w_temp")) {
            showWeather(
                prefs.getInt("w_temp", 0),
                prefs.getInt("w_code", 0),
                prefs.getString("geo_name", "") ?: ""
            )
        }
    }

    private fun showWeather(temp: Int, code: Int, name: String) {
        tempText.text = (if (temp > 0) "+" else "") + temp + "°"
        descText.text = Weather.describe(code) + (if (name.isNotEmpty()) " · $name" else "")
        weatherIcon.code = code
    }

    private fun loadWeather() {
        lastWeather = System.currentTimeMillis()
        val city = prefs.getString("city", "Москва") ?: "Москва"
        io.execute {
            try {
                var geo: Weather.Geo? = null
                val sl = prefs.getString("lat", null)?.toDoubleOrNull()
                val so = prefs.getString("lon", null)?.toDoubleOrNull()
                if (sl != null && so != null && prefs.getString("geo_for", "") == city) {
                    geo = Weather.Geo(prefs.getString("geo_name", city) ?: city, sl, so)
                } else {
                    geo = Weather.geocode(city)
                    if (geo != null) {
                        prefs.edit()
                            .putString("lat", geo.lat.toString())
                            .putString("lon", geo.lon.toString())
                            .putString("geo_name", geo.name)
                            .putString("geo_for", city)
                            .apply()
                    }
                }
                val g = geo ?: run {
                    ui.post { descText.text = "Город не найден" }
                    return@execute
                }
                val r = Weather.fetch(g.lat, g.lon) ?: return@execute
                prefs.edit().putInt("w_temp", r.temp).putInt("w_code", r.code).apply()
                ui.post { showWeather(r.temp, r.code, g.name) }
            } catch (e: Exception) {
                // нет интернета — остаются прошлые данные
            }
        }
    }

    // ---------------------------------------------------------------- очистка и входы

    /** Закрывает фоновые процессы приложений из списка (то, что система позволяет обычному приложению). */
    private fun cleanMemory() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = ActivityManager.MemoryInfo()
        am.getMemoryInfo(before)
        val pkgs = ArrayList<String>()
        for (t in tiles) {
            val cn = t.tag as? ComponentName
            if (cn != null) pkgs.add(cn.packageName)
        }
        toast("Очищаю…")
        io.execute {
            for (p in pkgs) {
                try {
                    am.killBackgroundProcesses(p)
                } catch (e: Exception) {
                }
            }
            try {
                Thread.sleep(900)
            } catch (e: InterruptedException) {
            }
            val after = ActivityManager.MemoryInfo()
            am.getMemoryInfo(after)
            val freed = ((after.availMem - before.availMem) / (1024 * 1024)).toInt()
            ui.post {
                toast(if (freed > 20) "Готово: освобождено около $freed МБ" else "Готово: фоновые приложения закрыты")
            }
        }
    }

    /** Открывает другой главный экран (например, родной экран ТВ), если он есть. */
    private fun exitToNative() {
        val q = Intent(Intent.ACTION_MAIN)
        q.addCategory(Intent.CATEGORY_HOME)
        val others = ArrayList<ResolveInfo>()
        for (ri in packageManager.queryIntentActivities(q, 0)) {
            if (ri.activityInfo.packageName != packageName) others.add(ri)
        }
        if (others.isEmpty()) {
            toast("Другой главный экран не найден")
            return
        }
        val openHome = { ri: ResolveInfo ->
            try {
                val i = Intent(Intent.ACTION_MAIN)
                i.component = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
                toast("Не удалось открыть")
            }
        }
        if (others.size == 1) {
            openHome(others[0])
        } else {
            val names = ArrayList<String>()
            for (ri in others) names.add(ri.loadLabel(packageManager).toString())
            AlertDialog.Builder(this)
                .setTitle("Выход в…")
                .setItems(names.toTypedArray()) { _, which -> openHome(others[which]) }
                .show()
        }
    }

    /** Список входов (HDMI и т.п.), если ТВ отдаёт его приложениям. */
    private fun showInputs() {
        val tm = getSystemService(Context.TV_INPUT_SERVICE) as? TvInputManager
        val list = ArrayList<android.media.tv.TvInputInfo>()
        try {
            if (tm != null) {
                for (i in tm.tvInputList) if (i.isPassthroughInput) list.add(i)
            }
        } catch (e: Exception) {
        }
        if (list.isEmpty()) {
            toast("Этот ТВ не отдаёт список входов приложениям. Используйте кнопку «Источник» на пульте.")
            return
        }
        val names = ArrayList<String>()
        for (i in list) names.add(i.loadLabel(this)?.toString() ?: i.id)
        AlertDialog.Builder(this)
            .setTitle("Источник сигнала")
            .setItems(names.toTypedArray()) { _, which ->
                try {
                    val uri = TvContract.buildChannelUriForPassthroughInput(list[which].id)
                    val i = Intent(Intent.ACTION_VIEW, uri)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                    toast("Не удалось переключить. Используйте кнопку «Источник» на пульте.")
                }
            }
            .show()
    }

    // ---------------------------------------------------------------- настройки

    private fun showSettings() {
        val items = arrayOf("Фон", "Город для погоды", "Размер плиток", "Размер погоды", "Сбросить главный экран")
        AlertDialog.Builder(this)
            .setTitle("Настройки")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showBgDialog()
                    1 -> askCity()
                    2 -> showSizeDialog()
                    3 -> showWeatherSizeDialog()
                    4 -> {
                        prefs.edit().remove("order").remove("pinned").apply()
                        loadApps()
                    }
                }
            }
            .show()
    }

    private fun showBgDialog() {
        val names = ArrayList<String>()
        names.addAll(bgNames)
        names.add("Своя картинка из файла…")
        names.add("Картинка по ссылке…")
        AlertDialog.Builder(this)
            .setTitle("Фон")
            .setItems(names.toTypedArray()) { _, which ->
                when {
                    which < bgNames.size -> {
                        prefs.edit().putString("bg", "p$which").apply()
                        loadBackground()
                    }
                    which == bgNames.size -> pickImage()
                    else -> askUrl()
                }
            }
            .show()
    }

    private fun pickImage() {
        try {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i, 7)
        } catch (e: Exception) {
            toast("На этом ТВ нет выбора файлов. Используйте «Картинка по ссылке».")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            io.execute {
                try {
                    val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    setCustomBackground(bytes)
                } catch (e: Exception) {
                    ui.post { toast("Не удалось открыть файл") }
                }
            }
        }
    }

    private fun askUrl() {
        val et = EditText(this)
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_TEXT_VARIATION_URI
        et.hint = "https://…/картинка.jpg"
        AlertDialog.Builder(this)
            .setTitle("Ссылка на картинку")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val url = et.text.toString().trim()
                if (url.isNotEmpty()) {
                    toast("Загружаю…")
                    io.execute {
                        try {
                            setCustomBackground(Net.getBytes(url))
                        } catch (e: Exception) {
                            ui.post { toast("Не удалось скачать картинку") }
                        }
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun askCity() {
        val et = EditText(this)
        et.setSingleLine(true)
        et.setText(prefs.getString("city", "Москва"))
        et.setSelectAllOnFocus(true)
        AlertDialog.Builder(this)
            .setTitle("Город для погоды")
            .setView(et)
            .setPositiveButton("OK") { _, _ ->
                val c = et.text.toString().trim()
                if (c.isNotEmpty()) {
                    prefs.edit().putString("city", c).apply()
                    loadWeather()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showWeatherSizeDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(16), dp(24), dp(8))
        val info = TextView(this)
        val bar = SeekBar(this)
        bar.max = 4
        bar.progress = prefs.getInt("wscale", 2).coerceIn(0, 4)
        info.text = "Размер погоды: " + (bar.progress + 1) + " из 5   (←  меньше,  больше  →)"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.edit().putInt("wscale", p).apply()
                info.text = "Размер погоды: " + (p + 1) + " из 5   (←  меньше,  больше  →)"
                applyWeatherSize()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(info)
        box.addView(bar)
        AlertDialog.Builder(this)
            .setTitle("Размер погоды")
            .setView(box)
            .setPositiveButton("Готово", null)
            .show()
    }

    private fun showSizeDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(16), dp(24), dp(8))
        val info = TextView(this)
        val bar = SeekBar(this)
        bar.max = 5
        bar.progress = (10 - cols).coerceIn(0, 5)
        info.text = "Размер: " + (bar.progress + 1) + " из 6   (←  меньше,  больше  →)"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                cols = 10 - p
                prefs.edit().putInt("cols2", cols).apply()
                info.text = "Размер: " + (p + 1) + " из 6   (←  меньше,  больше  →)"
                relayout()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(info)
        box.addView(bar)
        AlertDialog.Builder(this)
            .setTitle("Размер плиток")
            .setView(box)
            .setPositiveButton("Готово", null)
            .show()
    }
}
